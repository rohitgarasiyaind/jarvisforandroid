
import pyttsx3
import speech_recognition as sr
from playsound import playsound
import os
import platform

# Initialize the text-to-speech engine
engine = pyttsx3.init()

# Configure the voice
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)  # Use the first voice. Change to voices[1] for a different one.
engine.setProperty('rate', 170)  # Speed of the voice

# Functions for text-to-speech
def speak(text):
    engine.say(text)
    engine.runAndWait()

# Startup sound
def startup():
    playsound("startup.mp3")
    speak("Hello, I am Jarvis. How can I assist you today?")

# Shutdown sound
def shutdown():
    speak("Goodbye! Shutting down.")
    playsound("shutdown.mp3")

# Listening to user input
def listen():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        recognizer.adjust_for_ambient_noise(source)  # Adjust to ambient noise level
        try:
            audio = recognizer.listen(source)
            command = recognizer.recognize_google(audio)
            print(f"You said: {command}")
            return command.lower()
        except sr.UnknownValueError:
            speak("Sorry, I couldn't understand that.")
        except sr.RequestError:
            speak("There was a problem with the speech recognition service.")
        return ""

# Flashlight control
def toggle_flashlight(state):
    system = platform.system()
    
    if system == "Windows":
        if state == "on":
            os.system("powershell -Command \"Start-Process cmd -ArgumentList '/c echo flashlight is ON' -Verb RunAs\"")
            speak("Flashlight turned on.")
        elif state == "off":
            os.system("powershell -Command \"Start-Process cmd -ArgumentList '/c echo flashlight is OFF' -Verb RunAs\"")
            speak("Flashlight turned off.")
    elif system == "Android":
        try:
            import androidhelper  # Use the SL4A library for Android
            droid = androidhelper.Android()
            if state == "on":
                droid.cameraStartPreview()
                speak("Flashlight turned on.")
            elif state == "off":
                droid.cameraStopPreview()
                speak("Flashlight turned off.")
        except ImportError:
            speak("Flashlight control is not available on this device.")
    else:
        speak("Flashlight control is not supported on this operating system.")

# Main function
def main():
    startup()
    while True:
        command = listen()

        if "hello" in command:
            speak("Hello! How can I help you?")
        elif "your name" in command:
            speak("I am Jarvis, your personal assistant.")
        elif "turn on flashlight" in command:
            toggle_flashlight("on")
        elif "turn off flashlight" in command:
            toggle_flashlight("off")
        elif "shutdown" in command or "goodbye" in command:
            shutdown()
            break
        elif command:
            speak("I am not programmed to do that yet. Please try something else.")

if __name__ == "__main__":
    main()
